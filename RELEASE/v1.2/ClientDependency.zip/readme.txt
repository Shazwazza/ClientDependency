Project Home:
http://www.farmcode.org/page/ASPNet-ClientDependency-Framework.aspx

Source Code:
http://clientdependency.codeplex.com/

Documentation:
http://clientdependency.codeplex.com/
http://clientdependency.codeplex.com/documentation

See Web.config file for example and documentation on implementation